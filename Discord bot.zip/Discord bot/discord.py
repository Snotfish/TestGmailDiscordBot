import os
import requests


def send_discord_message(webhook_url, message):
    headers = {
        "Content-Type": "application/json"
    }
    data = {
        "content": message
    }
    response = requests.post(webhook_url, headers=headers, json=data)
    if response.status_code != 204:
        print(f"Failed to send Discord message. Status code: {response.status_code}.")


def get_discord_webhook_url():
    return os.environ.get('https://discord.com/api/webhooks/1089177017561399426/pi0dYXcWPHXvXGTIQUaskPuQO9n0Q_Hmqma9Sb-wEH0fMRU-VgWen7ZiJoB8r_LIPTQy')


def send_email_to_discord(email):
    message = f"**From:** {email['From']}\n**Subject:** {email['Subject']}\n**Body:** {email['Body']}"
    webhook_url = get_discord_webhook_url()
    send_discord_message(webhook_url, message)
