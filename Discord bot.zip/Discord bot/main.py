from gmail import read_emails
from discord import send_email_to_discord


# Define the search query to filter emails
search_query = "is:unread"

# Read the emails from Gmail and send them to Discord
emails = read_emails(search_query)
for email in emails:
    send_email_to_discord(email)
